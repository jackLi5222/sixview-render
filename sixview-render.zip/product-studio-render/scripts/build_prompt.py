#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_prompt.py — 极简高级工业设计摄影棚渲染图的提示词组装器

职责（单一、确定性）：
  输入「产品描述 + 风格参数」→ 校验 → 组装为可直接交给 ImageGen 的中英双语提示词 →
  以结构化 JSON 输出到 stdout，供调用方（WorkBuddy / ImageGen 工作流）消费。

硬性约束（自动注入，无需传参）：
  - 组件数量约束：所有组件均为单件（只出现一次），唯一例外是螺丝/螺母/螺帽等紧固件可成组出现；
  - 相机/记录仪类产品额外注入 20 组件单件 BOM（上壳体……铭牌标签壳，各 1 件）。

输入（JSON，来自 --json 参数 / --json-file 文件 / stdin，三选一）：
  {
    "product":  str,   必填，产品主体描述，如 "桌面超声波加湿器，圆柱形机身"
    "six_view": bool,  可选，六视图模式：单张图内 2×3 网格呈现六个视角，默认 true（明确要求单视角时传 false）
    "view":     str,   可选，视角（six_view=true 时忽略），默认 "three-quarter"
    "material": str,   可选，主材质，默认 "matte-plastic"
    "lighting": str,   可选，布光风格，默认 "soft-studio"
    "mood":     str,   可选，画面基调，默认 "minimal-premium"
    "extra":    str,   可选，附加描述（自由文本，追加到提示词末尾）
    "count":    int,   可选，建议出图张数 1-4，默认 1
  }

输出（JSON，始终写入 stdout）：
  成功: {"ok": true,  "prompt": str, "negative_prompt": str, "params": {...}, "warnings": [...], "suggested_size": str}
  失败: {"ok": false, "error": {"code": str, "message": str, "hint": str}}

退出码：0 = 成功；2 = 输入/校验错误；3 = 内部异常。

用法示例：
  python build_prompt.py --product "桌面加湿器"
  python build_prompt.py --json-file render_request.json
  echo '{"product":"筋膜枪","material":"leather"}' | python build_prompt.py --stdin
"""

import argparse
import json
import sys

# ---------------------------------------------------------------------------
# 1. 受控词表（枚举约束，保证风格稳定、可扩展）
#    新增风格时只需在下表中加一行，无需改动组装逻辑。
# ---------------------------------------------------------------------------

VIEWS = {
    "three-quarter": ("三分之四视角", "three-quarter perspective view"),
    "front":         ("正面平视视角", "straight-on front view"),
    "side":          ("正侧面视角", "perfect side profile view"),
    "back":          ("正后方视角", "straight-on rear view"),
    "top":           ("俯视视角", "top-down view"),
    "bottom":        ("仰视视角", "bottom-up view"),
}

MATERIALS = {
    "matte-plastic":  ("细腻哑光塑料质感", "fine matte plastic, realistic material texture"),
    "brushed-metal":  ("拉丝金属质感", "brushed anodized aluminum, realistic metal texture"),
    "leather":        ("头层皮革质感", "genuine leather with visible grain"),
    "fabric":         ("织物面料质感", "woven fabric upholstery"),
    "glass":          ("磨砂玻璃质感", "frosted glass, subtle translucency"),
}

LIGHTING = {
    "soft-studio": ("柔和光影，柔和投影", "soft diffused studio lighting, soft drop shadow"),
    "high-key":    ("明亮高调，均匀照明", "bright high-key lighting, even illumination"),
    "rim":         ("轮廓光勾勒边缘", "subtle rim lighting outlining the silhouette"),
}

MOODS = {
    "minimal-premium": ("极简风格，高级感", "minimalist premium industrial design"),
    "tech":            ("极简风格，科技感", "minimalist high-tech aesthetic"),
    "warm":            ("极简风格，温润家居感", "minimalist warm homeware aesthetic"),
}

# 固定基底：来自项目《要求.txt》的核心风格词，任何请求都必须包含
BASE_ZH = "工业设计渲染，纯白摄影棚，产品主体居中，真实材质质感，cinematic"
BASE_EN = "professional industrial design render, pure white photography studio, product as the main subject, photorealistic, cinematic"

# 六视图模式：单次生成、单张图内呈现六个视角
SIX_VIEW_ZH = ("同一画面内以 2行×3列 网格排列该产品的六个视角，六个格子必须分别展示产品六个不同的面，"
               "朝向各不相同、严禁任何两个格子重复同一朝向："
               "上排为正面平视（正对镜头面）、正后方（背对镜头的后壳面）、正侧面（90度侧轮廓）；"
               "下排为俯视（垂直向下看顶面，看不到镜头）、仰视（垂直向上看底面）、三分之四视角；"
               "六个视角必须是完全同款产品（同造型、同配色、同材质），大小一致、间距均匀")
SIX_VIEW_EN = ("a single image showing six orthographic views of the SAME product in a 2x3 grid, "
               "each cell must show a DIFFERENT face of the product with a distinct camera angle, "
               "no two cells may share the same viewing direction: "
               "front view (lens facing viewer), rear view (back housing), 90-degree side profile on the top row; "
               "strict top-down view (top face only, lens not visible), strict bottom-up view (bottom face only), "
               "three-quarter view on the bottom row; "
               "identical product design in every cell, uniform size and even spacing")

NEGATIVE_PROMPT = (
    "杂乱背景, 文字水印, 人物, 手部, 过度曝光, 噪点, 低分辨率, 畸变, "
    "重复组件, 同一组件出现多次, "
    "cluttered background, watermark, text overlay, people, hands, overexposed, noise, distorted geometry, "
    "duplicated components, the same component appearing more than once"
)

# ---------------------------------------------------------------------------
# 1.6 组件数量硬性规定：所有组件均为单件（每个组件只出现一次），
#     唯一例外：螺丝 / 螺母 / 螺帽等紧固件可成组出现多颗。
#     注意：孔阵列、格栅、网罩、纹理等属于表面纹理，不计为组件，不受此约束。
#     该约束全局注入所有提示词。
# ---------------------------------------------------------------------------

COMPONENT_COUNT_ZH = ("组件数量约束：所有组件均为单件、每个组件只出现一次，"
                      "唯一例外是螺丝、螺母、螺帽等紧固件可成组出现多颗；"
                      "严禁任何其他组件出现第二件（如两个镜头、两块前面板、多颗按键等均不允许）")
COMPONENT_COUNT_EN = ("component count constraint: every component is a single instance and appears exactly once; "
                      "the ONLY exception is fasteners such as screws, nuts and bolt caps, which may appear in multiples; "
                      "no other component may be duplicated (no second lens, no extra front panel, no multiple buttons)")

# 相机/记录仪类产品标准 BOM（单件清单，20 个组件各 1 件）：
# 命中 dashcam-camera 品类时注入，约束组件构成与数量。
CAMERA_BOM_ZH = ("组件构成（每种各 1 件，共 20 个组件）：上壳体、下壳体、前面板、后面板、侧装饰板、"
                 "镜头镜片/透明视窗、功能按键、硅胶密封圈、内部固定支架、电池仓盖、电池压块、泡棉缓冲垫、"
                 "配重块、装饰堵盖、内部加强支撑板、转轴座、转轴盖板、防滑胶垫、接口防尘塞、铭牌标签壳")
CAMERA_BOM_EN = ("component breakdown, exactly one of each of the 20 parts: upper housing, lower housing, front panel, "
                 "rear panel, side trim panel, lens glass / transparent window, function button, silicone sealing ring, "
                 "internal mounting bracket, battery compartment cover, battery clamp, foam cushion pad, counterweight block, "
                 "decorative plug cap, internal reinforcement plate, hinge seat, hinge cover plate, anti-slip rubber pad, "
                 "port dust plug, nameplate label shell")

# ---------------------------------------------------------------------------
# 1.5 产品类别 → 分部件纹理映射（按 product 关键词匹配，从上到下首个命中生效）
#     details: 注入提示词的分部件纹理细节（这是"纹理根据产品设计"的核心）
#     material: 用户未指定 material 时的智能推荐
#     新增类别只需在列表头部插入一行元组。
# ---------------------------------------------------------------------------

CATEGORY_HINTS = [
    (("域控", "域控制器", "ECU", "车载控制器", "控制器"),
     "domain-controller", "brushed-metal",
     "细节：压铸铝合金外壳带密集散热鳍片，边缘为精密CNC加工，端面有多针脚车载连接器接口阵列，表面有激光蚀刻标识区",
     "details: die-cast aluminum enclosure with dense cooling fins, precision CNC-machined edges, multi-pin automotive connector array on end faces, laser-etched marking area"),
    (("记录仪", "相机", "摄像头", "镜头", "摄影"),
     "dashcam-camera", "matte-plastic",
     "细节：镜头为镀蓝膜玻璃镜片与金属镜头环，机身有CNC高光倒角、精密麦克风孔阵列与状态指示灯",
     "details: sapphire-blue coated glass lens with metal lens ring, CNC chamfered edges, precise microphone hole array, status LED"),
    (("耳机", "音箱", "音响", "播放器"),
     "audio", "fabric",
     "细节：发声单元为织物网罩，头梁为金属材质，接触部位为亲肤硅胶",
     "details: fabric mesh over drivers, metal headband, skin-friendly silicone on contact areas"),
    (("加湿器", "香薰", "雾化"),
     "humidifier", "glass",
     "细节：水箱为磨砂半透明材质可见水位线，机身旋钮为阳极氧化铝",
     "details: frosted translucent water tank with visible waterline, anodized aluminum knob"),
    (("电钻", "工具", "筋膜枪", "打磨"),
     "power-tool", "matte-plastic",
     "细节：握把为防滑橡胶包裹，夹头为金属材质带滚花纹理，机身有散热格栅",
     "details: anti-slip rubber grip, knurled metal chuck, heat dissipation grilles"),
    (("水杯", "保温", "咖啡", "茶壶"),
     "drinkware", "brushed-metal",
     "细节：杯身为拉丝不锈钢，杯口为圆角抛光，杯底有防滑硅胶圈",
     "details: brushed stainless steel body, polished rounded rim, anti-slip silicone base ring"),
    (("按摩", "颈椎", "护腰"),
     "massager", "leather",
     "细节：接触面为亲肤硅胶带指压凸点，机身包裹皮革，按键区为金属",
     "details: skin-friendly silicone contact surface with acupressure nodes, leather-wrapped body, metal buttons"),
    (("投影", "幕布"),
     "projector", "fabric",
     "细节：面板为声学织物，镜头为镀膜玻璃，接口区有拉丝金属饰板",
     "details: acoustic fabric panel, coated glass lens, brushed metal trim around ports"),
    (("风扇", "循环扇", "净化"),
     "fan", "matte-plastic",
     "细节：网罩为细密格栅，扇叶为半透明材质，底座配橡胶脚垫",
     "details: fine mesh grille, translucent blades, rubber feet on base"),
]

MAX_PRODUCT_LEN = 200
MAX_EXTRA_LEN = 120


# ---------------------------------------------------------------------------
# 2. 错误处理：结构化错误 + 明确退出码
# ---------------------------------------------------------------------------

class PromptBuildError(Exception):
    """携带错误码与修复提示的业务异常。"""

    def __init__(self, code: str, message: str, hint: str = ""):
        super().__init__(message)
        self.code = code
        self.message = message
        self.hint = hint


def emit(payload: dict, exit_code: int) -> None:
    """统一出口：JSON 序列化到 stdout 并按退出码结束。"""
    json.dump(payload, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
    sys.exit(exit_code)


def fail(err: PromptBuildError) -> None:
    emit({"ok": False, "error": {"code": err.code, "message": err.message, "hint": err.hint}}, 2)


# ---------------------------------------------------------------------------
# 3. 输入校验
# ---------------------------------------------------------------------------

def _pick(table: dict, key: str, field: str, warnings: list) -> tuple:
    """从受控词表取值；未知值回退到表内第一项并记录警告，而不是直接报错。"""
    if key in table:
        return table[key]
    fallback_key = next(iter(table))
    warnings.append(
        f"未知的 {field} 值 '{key}'，已回退为 '{fallback_key}'。"
        f"可选值：{', '.join(table.keys())}"
    )
    return table[fallback_key]


def match_category(product: str):
    """按关键词匹配产品类别，返回 (category, recommended_material_key, detail_zh, detail_en)；未命中返回 None。"""
    for keywords, cat, mat, det_zh, det_en in CATEGORY_HINTS:
        if any(k in product for k in keywords):
            return cat, mat, det_zh, det_en
    return None


def validate(raw: dict) -> tuple[dict, list]:
    """校验并规范化输入，返回 (params, warnings)。校验失败抛 PromptBuildError。"""
    if not isinstance(raw, dict):
        raise PromptBuildError(
            "INVALID_INPUT", "输入必须是 JSON 对象。",
            '示例：{"product": "桌面加湿器"}',
        )

    product = str(raw.get("product") or "").strip()
    if not product:
        raise PromptBuildError(
            "EMPTY_PRODUCT", "缺少必填字段 'product'（产品主体描述）。",
            '示例：{"product": "桌面超声波加湿器，圆柱形哑光白机身"}',
        )
    if len(product) > MAX_PRODUCT_LEN:
        raise PromptBuildError(
            "PRODUCT_TOO_LONG", f"'product' 超过 {MAX_PRODUCT_LEN} 字符上限（当前 {len(product)}）。",
            "把细节移到 'extra' 字段，或精简描述。",
        )

    extra = str(raw.get("extra") or "").strip()
    if len(extra) > MAX_EXTRA_LEN:
        raise PromptBuildError(
            "EXTRA_TOO_LONG", f"'extra' 超过 {MAX_EXTRA_LEN} 字符上限（当前 {len(extra)}）。",
            "只保留最关键的补充描述。",
        )

    count = raw.get("count", 1)
    if not isinstance(count, int) or not 1 <= count <= 4:
        raise PromptBuildError(
            "INVALID_COUNT", "'count' 必须是 1-4 的整数。",
            "单次建议出图 1-4 张，批量出图请多次调用。",
        )

    warnings: list = []
    # 类别匹配：注入分部件纹理；用户未指定 material 时采用类别推荐材质
    category = match_category(product)
    user_material = raw.get("material")
    if category:
        cat, rec_mat, det_zh, det_en = category
    else:
        cat, rec_mat, det_zh, det_en = None, None, "", ""
    params = {
        "product": product,
        "six_view": bool(raw.get("six_view", True)),
        "view": _pick(VIEWS, str(raw.get("view", "three-quarter")), "view", warnings),
        "material": _pick(MATERIALS, str(user_material if user_material else (rec_mat or "matte-plastic")), "material", warnings),
        "lighting": _pick(LIGHTING, str(raw.get("lighting", "soft-studio")), "lighting", warnings),
        "mood": _pick(MOODS, str(raw.get("mood", "minimal-premium")), "mood", warnings),
        "category": cat,
        "detail_zh": det_zh,
        "detail_en": det_en,
        "extra": extra,
        "count": count,
    }
    if params["six_view"] and params["view"][0] != VIEWS["three-quarter"][0]:
        warnings.append("six_view 模式下 view 字段被忽略（六视图网格已包含全部视角）。")
    return params, warnings


# ---------------------------------------------------------------------------
# 4. 提示词组装（核心逻辑）
# ---------------------------------------------------------------------------

def assemble(params: dict) -> str:
    """按「基底 → 主体 → 材质 → 视角/六视图 → 布光 → 基调 → 附加」的固定顺序组装，
    顺序即权重：越靠前对生成结果影响越大。six_view 模式用网格指令替换单一视角。"""
    if params["six_view"]:
        view_zh, view_en = SIX_VIEW_ZH, SIX_VIEW_EN
    else:
        view_zh, view_en = params["view"]
    zh_parts = [
        BASE_ZH,
        f"产品主体：{params['product']}",
        params["material"][0],
        view_zh,
        params["lighting"][0],
        params["mood"][0],
    ]
    en_parts = [
        BASE_EN,
        f"subject: {params['product']}",
        params["material"][1],
        view_en,
        params["lighting"][1],
        params["mood"][1],
    ]
    if params["extra"]:
        zh_parts.append(params["extra"])
        en_parts.append(params["extra"])
    # 分部件纹理细节：紧随基调之后，权重足够影响材质表现
    if params["detail_zh"]:
        zh_parts.append(params["detail_zh"])
        en_parts.append(params["detail_en"])
    # 相机/记录仪类：注入 20 组件单件 BOM
    if params["category"] == "dashcam-camera":
        zh_parts.append(CAMERA_BOM_ZH)
        en_parts.append(CAMERA_BOM_EN)
    # 组件数量硬性约束：全局注入，收尾权重确保不被稀释
    zh_parts.append(COMPONENT_COUNT_ZH)
    en_parts.append(COMPONENT_COUNT_EN)
    return "；".join(zh_parts) + " | " + ", ".join(en_parts)


# ---------------------------------------------------------------------------
# 5. CLI 入口
# ---------------------------------------------------------------------------

def read_input(args: argparse.Namespace) -> dict:
    """三种输入通道，优先级：--json > --json-file > --stdin > 单字段参数。"""
    if args.json:
        text = args.json
    elif args.json_file:
        try:
            with open(args.json_file, "r", encoding="utf-8") as f:
                text = f.read()
        except OSError as e:
            raise PromptBuildError("FILE_ERROR", f"无法读取输入文件：{args.json_file}", str(e))
    elif args.stdin:
        text = sys.stdin.read()
    else:
        # 便捷模式：仅产品名，其余走默认值
        if not args.product:
            raise PromptBuildError(
                "NO_INPUT", "未提供任何输入。",
                "使用 --product / --json / --json-file / --stdin 之一，详见 --help。",
            )
        return {"product": args.product}

    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        raise PromptBuildError("INVALID_JSON", f"输入不是合法 JSON：{e}", '示例：{"product": "加湿器"}')


def main() -> None:
    parser = argparse.ArgumentParser(description="极简高级工业设计摄影棚渲染提示词组装器")
    parser.add_argument("--product", help="产品主体描述（便捷模式，等价于 --json '{\"product\": ...}'）")
    parser.add_argument("--json", help="完整 JSON 参数字符串")
    parser.add_argument("--json-file", help="从 JSON 文件读取参数")
    parser.add_argument("--stdin", action="store_true", help="从标准输入读取 JSON 参数")
    args = parser.parse_args()

    try:
        raw = read_input(args)
        params, warnings = validate(raw)
        result = {
            "ok": True,
            "prompt": assemble(params),
            "negative_prompt": NEGATIVE_PROMPT,
            "params": {
                "product": params["product"],
                "six_view": params["six_view"],
                "view": next(k for k, v in VIEWS.items() if v == params["view"]),
                "material": next(k for k, v in MATERIALS.items() if v == params["material"]),
                "lighting": next(k for k, v in LIGHTING.items() if v == params["lighting"]),
                "mood": next(k for k, v in MOODS.items() if v == params["mood"]),
                "category": params["category"],
                "extra": params["extra"],
                "count": params["count"],
            },
            "warnings": warnings,
            # 六视图网格为横幅比例；单视角为方图
            "suggested_size": "1536x1024" if params["six_view"] else "1024x1024",
        }
        emit(result, 0)
    except PromptBuildError as e:
        fail(e)
    except Exception as e:  # 兜底：任何未预期异常都以结构化形式抛出，绝不泄漏 traceback 给调用方
        emit({"ok": False, "error": {"code": "INTERNAL_ERROR", "message": str(e),
                                     "hint": "请检查输入后重试；若持续出现请反馈该错误信息。"}}, 3)


if __name__ == "__main__":
    main()

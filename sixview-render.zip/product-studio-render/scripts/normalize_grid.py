#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
normalize_grid.py — 六视图网格图的产品尺寸标准化器

解决的问题：图生图生成的 2×3 六视图网格中，各视角产品大小不一。
本脚本利用纯白背景特性，确定性地完成：网格分割 → 产品边界框检测 →
统一缩放 → 重排输出。不依赖任何 AI，结果可复现。

输入：
  --input       网格图路径（PNG/JPG，白底）
  --output-dir  输出目录
  --labels      逗号分隔的视角标签，按行优先顺序，如 "front,back,side,top,bottom,three-quarter"
  --rows/--cols 网格行列数，默认 2 3
  --cell        输出单图边长（像素），默认 512
  --grid-output 重排后的网格图文件名（相对 output-dir），省略则不输出网格

输出：
  <output-dir>/<prefix>_<label>.png   每个视角一张标准化单图（产品等大居中）
  <output-dir>/<grid-output>          重排后的等大网格图（可选）
  stdout 打印各视角原始产品 bbox 尺寸与缩放比，供核对

退出码：0 成功；2 输入错误；3 内部错误。
"""

import argparse
import sys
from pathlib import Path

from PIL import Image

WHITE_THRESHOLD = 245      # 灰度 >= 此值视为白背景
GUTTER_MIN_RUN = 15        # 分割带（全白行/列）的最小连续宽度
CELL_MARGIN_RATIO = 0.06   # 单元格内产品 bbox 外扩比例（留呼吸空间）
PRODUCT_FILL_RATIO = 0.82  # 产品在输出单图中的最大占幅


class NormalizeError(Exception):
    pass


def load_image(path: str) -> Image.Image:
    p = Path(path)
    if not p.is_file():
        raise NormalizeError(f"输入文件不存在：{path}")
    img = Image.open(p).convert("RGB")
    if img.width < 100 or img.height < 100:
        raise NormalizeError(f"图像尺寸过小（{img.width}x{img.height}），疑似非网格图。")
    return img


def find_gutters(img: Image.Image, axis: str) -> list[int]:
    """沿 axis（'x' 为列扫描 / 'y' 为行扫描）找出全白分割带的中心位置。"""
    gray = img.convert("L")
    w, h = gray.size
    limit = h if axis == "x" else w
    span = 1 if axis == "x" else 0

    def is_line(idx: int) -> bool:
        # 抽样行/列（每隔 4 像素取一点）判断是否全白，抗轻微噪点
        line = gray.crop((idx, 0, idx + 1, h)) if axis == "x" else gray.crop((0, idx, w, idx + 1))
        data = line.tobytes()
        return all(v >= WHITE_THRESHOLD for v in data[::4])

    runs: list[tuple[int, int]] = []
    start = None
    for i in range(limit):
        if is_line(i):
            if start is None:
                start = i
        else:
            if start is not None:
                if i - start >= GUTTER_MIN_RUN:
                    runs.append((start, i))
                start = None
    if start is not None and limit - start >= GUTTER_MIN_RUN:
        runs.append((start, limit))
    return [(a + b) // 2 for a, b in runs]


def split_cells(img: Image.Image, rows: int, cols: int) -> list[Image.Image]:
    """先用全白分割带切分；失败则回退到等分。返回行优先顺序的单元格列表。"""
    w, h = img.size
    vx = find_gutters(img, "x")
    hy = find_gutters(img, "y")
    # 过滤贴边的伪分割带
    vx = [x for x in vx if 20 < x < w - 20]
    hy = [y for y in hy if 20 < y < h - 20]

    if len(vx) == cols - 1 and len(hy) == rows - 1:
        xs = [0] + vx + [w]
        ys = [0] + hy + [h]
    else:
        print(f"[warn] 分割带检测到 x={len(vx)}（需{cols - 1}）y={len(hy)}（需{rows - 1}），回退等分", file=sys.stderr)
        xs = [round(i * w / cols) for i in range(cols + 1)]
        ys = [round(j * h / rows) for j in range(rows + 1)]

    cells = []
    for j in range(rows):
        for i in range(cols):
            cells.append(img.crop((xs[i], ys[j], xs[i + 1], ys[j + 1])))
    return cells


def product_bbox(cell: Image.Image) -> tuple[int, int, int, int]:
    """检测单元格内非白内容（产品+投影）的边界框。"""
    gray = cell.convert("L")
    w, h = gray.size
    px = gray.load()
    left, top, right, bottom = w, h, -1, -1
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            if px[x, y] < WHITE_THRESHOLD:
                if x < left:
                    left = x
                if x > right:
                    right = x
                if y < top:
                    top = y
                if y > bottom:
                    bottom = y
    if right < 0:
        raise NormalizeError(f"单元格内未检测到产品内容（全白）。")
    # 外扩留白
    mx, my = int((right - left) * CELL_MARGIN_RATIO), int((bottom - top) * CELL_MARGIN_RATIO)
    left, top = max(0, left - mx), max(0, top - my)
    right, bottom = min(w, right + mx), min(h, bottom + my)
    return left, top, right, bottom


def normalize_cell(cell: Image.Image, out_size: int) -> tuple[Image.Image, tuple[int, int]]:
    """把单元格内产品缩放到统一占幅、居中放在白底正方形上。返回 (新图, 原始产品尺寸)。"""
    box = product_bbox(cell)
    orig_size = (box[2] - box[0], box[3] - box[1])
    product = cell.crop(box)

    target = int(out_size * PRODUCT_FILL_RATIO)
    product.thumbnail((target, target), Image.LANCZOS)

    canvas = Image.new("RGB", (out_size, out_size), (255, 255, 255))
    canvas.paste(product, ((out_size - product.width) // 2, (out_size - product.height) // 2))
    return canvas, orig_size


def main() -> None:
    parser = argparse.ArgumentParser(description="六视图网格产品尺寸标准化器")
    parser.add_argument("--input", required=True, help="网格图路径")
    parser.add_argument("--output-dir", required=True, help="输出目录")
    parser.add_argument("--labels", required=True, help="逗号分隔视角标签，行优先")
    parser.add_argument("--prefix", default="view", help="输出文件名前缀")
    parser.add_argument("--rows", type=int, default=2)
    parser.add_argument("--cols", type=int, default=3)
    parser.add_argument("--cell", type=int, default=512, help="输出单图边长")
    parser.add_argument("--grid-output", default=None, help="重排网格图文件名")
    args = parser.parse_args()

    try:
        labels = [s.strip() for s in args.labels.split(",") if s.strip()]
        expected = args.rows * args.cols
        if len(labels) != expected:
            raise NormalizeError(f"标签数 {len(labels)} 与网格格数 {expected} 不符。")

        img = load_image(args.input)
        cells = split_cells(img, args.rows, args.cols)

        out_dir = Path(args.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        normalized: list[Image.Image] = []
        report: list[str] = []
        for label, cell in zip(labels, cells):
            norm, orig = normalize_cell(cell, args.cell)
            normalized.append(norm)
            path = out_dir / f"{args.prefix}_{label}.png"
            norm.save(path)
            w_pct = orig[0] / cell.width * 100
            h_pct = orig[1] / cell.height * 100
            report.append(f"{label:<15} 原始产品bbox {orig[0]}x{orig[1]}px (占格 {w_pct:.0f}%x{h_pct:.0f}%) -> 统一为 {args.cell}px 等大")
            print(f"✅ {path.name}")

        if args.grid_output:
            grid = Image.new("RGB", (args.cell * args.cols, args.cell * args.rows), (255, 255, 255))
            for idx, norm in enumerate(normalized):
                r, c = divmod(idx, args.cols)
                grid.paste(norm, (c * args.cell, r * args.cell))
            grid_path = out_dir / args.grid_output
            grid.save(grid_path)
            print(f"✅ {grid_path.name}")

        print("\n各视角原始尺寸（标准化前，可直观看出差距）：")
        print("  " + "\n  ".join(report))
    except NormalizeError as e:
        print(f"[error] {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"[error] 内部异常：{e}", file=sys.stderr)
        sys.exit(3)


if __name__ == "__main__":
    main()
